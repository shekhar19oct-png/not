// console.log("✅ Content script loaded");
// function getPageData() {
//   let inputs = [];
//   document.querySelectorAll("input").forEach(input => {
//     inputs.push({
//       type: input.type,
//       name: input.name,
//       placeholder: input.placeholder
//     });
//   });

//   let buttons = [];
//   document.querySelectorAll("button").forEach(btn => {
//     buttons.push(btn.innerText);
//   });

//   return {
//     url: window.location.href,
//     inputs: inputs,
//     buttons: buttons
//   };
// }

// // Listen for request from popup
// chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
//   if (request.type === "GET_DATA") {
//     sendResponse(getPageData());
//   }
// });
console.log("✅ Content script loaded");

function getPageData() {
  let inputs = [];
  document.querySelectorAll("input").forEach(input => {
    inputs.push({
      type: input.type,
      name: input.name,
      placeholder: input.placeholder
    });
  });

  let buttons = [];
  document.querySelectorAll("button").forEach(btn => {
    buttons.push(btn.innerText);
  });

  return {
    url: window.location.href,
    inputs,
    buttons
  };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "GET_DATA") {
    console.log("📩 GET_DATA received");
    sendResponse(getPageData());
    return true; // ✅ VERY IMPORTANT
  }
});