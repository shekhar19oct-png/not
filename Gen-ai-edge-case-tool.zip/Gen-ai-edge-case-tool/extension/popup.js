console.log("Popup script loaded");

document.getElementById("analyze").addEventListener("click", async () => {
  console.log("Button clicked");

  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // TEMP: collect data directly using scripting API
  chrome.scripting.executeScript(
    {
      target: { tabId: tab.id },
      func: () => {
        let inputs = [];
        document.querySelectorAll("input").forEach(i =>
          inputs.push({
            type: i.type,
            name: i.name,
            placeholder: i.placeholder
          })
        );

        let buttons = [];
        document.querySelectorAll("button").forEach(b =>
          buttons.push(b.innerText)
        );

        return {
          url: location.href,
          inputs,
          buttons
        };
      }
    },
    async (results) => {
      console.log("Collected page data:", results[0].result);

      const res = await fetch("http://localhost:3000/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(results[0].result)
      });

      const data = await res.json();
      document.getElementById("result").innerText = data.output;
    }
  );
});