process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
import express from "express";
import fetch from "node-fetch";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

// ✅ Put your OpenRouter key here (NO billing required)
const OPENROUTER_API_KEY = "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";

app.post("/analyze", async (req, res) => {
  console.log("✅ /analyze hit");
  console.log("Received data:", req.body);

  const data = req.body;

  // ✅ Prompt (same as before)
  const prompt = `
You are a senior QA engineer.

Analyze the following automatically captured UI details
and test execution context.

Suggest ONLY relevant edge test cases that were NOT covered.
Avoid generic suggestions.

URL:
${data.url}

Input fields:
${data.inputs.map(i => `- ${i.name || "unnamed"} (${i.type})`).join("\n")}

Buttons:
${data.buttons.length > 0 ? data.buttons.join(", ") : "None detected"}

Provide 5–7 clear edge test case suggestions.
`;

  try {
    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
    
      headers: {
      "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
      "Content-Type": "application/json",
        "HTTP-Referer": "http://localhost:3000",
          "X-Title": "GenAI Edge Case Tool"
         },
      body: JSON.stringify({
        model: "mistralai/mistral-7b-instruct", // ✅ FREE MODEL
        messages: [
          {
            role: "user",
            content: prompt
          }
        ]
      })
    });

    const text = await response.text();

try {
  const result = JSON.parse(text);

  console.log("🤖 AI Raw Response:", result);

  const output =
    result.choices?.[0]?.message?.content ||
    "No edge cases generated.";

  res.json({ output });

} catch (err) {
  console.error("❌ Not JSON response:", text);
  res.status(500).json({ error: "Invalid response from AI" });
}


    console.log("🤖 AI Raw Response:", JSON.stringify(result, null, 2));

    // ✅ Extract output correctly
    const output =
      result.choices?.[0]?.message?.content ||
      "No edge cases generated.";

    res.json({ output });

  } catch (error) {
    console.error("❌ Error calling OpenRouter:", error.message);
    res.status(500).json({ error: "Failed to generate edge cases" });
  }
});

app.listen(3000, () => {
  console.log("🚀 Server running on http://localhost:3000");
});
